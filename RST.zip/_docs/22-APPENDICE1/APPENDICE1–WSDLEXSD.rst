+-----------------------------------------------------------------------+
| |AGID_logo_carta_intestata-02.png|                                    |
+-----------------------------------------------------------------------+

+------------------------------+
| **APPENDICE 1 – WSDL E XSD** |
+------------------------------+

Appendice 1 – WSDL e XSD

`Torna all'indice <../index.rst>`__

.. |AGID_logo_carta_intestata-02.png| image:: ../media/header.png
   :width: 5.90551in
   :height: 1.30277in
