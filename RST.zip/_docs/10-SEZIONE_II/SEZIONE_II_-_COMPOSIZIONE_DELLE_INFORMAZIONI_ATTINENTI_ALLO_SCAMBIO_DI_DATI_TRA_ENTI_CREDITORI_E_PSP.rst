+-----------------------------------------------------------------------+
| |AGID_logo_carta_intestata-02.png|                                    |
+-----------------------------------------------------------------------+

**Sezione II - COMPOSIZIONE DELLE INFORMAZIONI ATTINENTI ALLO SCAMBIO DI**
**DATI TRA Enti creditori E PSP**

Nella presente sezione sono date specifiche indicazioni circa lo scambio
di dati tra Enti Creditori, Nodo dei Pagamenti-SPC e Prestatori di
servizi di pagamento.

`Torna all'indice <../index.rst>`__

.. |AGID_logo_carta_intestata-02.png| image:: ../media/header.png
   :width: 5.90551in
   :height: 1.30277in
