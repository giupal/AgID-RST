# pagoPA - Specifiche Attuative del Nodo dei Pagamento-SPC 
Conversione in formato RST della versione 2.1 delle Specifiche Attuative del Nodo dei Pagamento-SPC 
